export enum AnnouncePackageStatus {
    DANGER = "danger",
    NORMAL = "normal"
}
export enum SortByEnum{
    DATE_DESC = "date_desc",
    DATE_ASC = "date_asc"
}