export enum CaresoftStatus {
    NotCareSoft = 0,
    IsCrm = 1,
    IsCron = 2
}