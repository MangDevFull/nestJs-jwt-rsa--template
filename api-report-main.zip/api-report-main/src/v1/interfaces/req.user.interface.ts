export interface RequestUser{
    name : string
    email:string,
    id: number,
    role:number
}