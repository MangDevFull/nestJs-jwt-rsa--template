export interface LooseObject {
    [key: string]: any
}
